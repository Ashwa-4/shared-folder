package shared_folder;

import java.awt.Desktop;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.SpringLayout;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeModel;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;


import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbFile;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Random;

public class Window_1 {

	private static JFrame frmSharedFolder;
	private JTextField txtusername;
	private JPasswordField txtpassword;
	private JTextField txthost;
	private JTextField txtPath;
	private JTree jTree;
	private HelperClass helper;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Window_1 window = new Window_1();
					window.frmSharedFolder.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Window_1() {
		initialize();
	}

	private void initialize() {
		helper = new HelperClass();
		frmSharedFolder = new JFrame();
		frmSharedFolder.setTitle("Shared Folder");
		frmSharedFolder.setResizable(false);
		frmSharedFolder.setBounds(100, 100, 662, 479);
		frmSharedFolder.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSharedFolder.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Shared Drive Project");
		lblNewLabel.setBounds(184, 24, 210, 25);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
		frmSharedFolder.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Username");
		lblNewLabel_1.setBounds(10, 69, 72, 16);
		frmSharedFolder.getContentPane().add(lblNewLabel_1);
		
		txtusername = new JTextField();
		txtusername.setBounds(94, 66, 217, 22);
		frmSharedFolder.getContentPane().add(txtusername);
		txtusername.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setBounds(10, 101, 72, 16);
		frmSharedFolder.getContentPane().add(lblNewLabel_2);
		
		txtpassword = new JPasswordField();
		txtpassword.setBounds(94, 98, 217, 22);
		frmSharedFolder.getContentPane().add(txtpassword);
		
		JLabel lblNewLabel_3 = new JLabel("Host");
		lblNewLabel_3.setBounds(357, 69, 56, 16);
		frmSharedFolder.getContentPane().add(lblNewLabel_3);
		
		txthost = new JTextField();
		txthost.setBounds(415, 66, 217, 22);
		txthost.setColumns(10);
		frmSharedFolder.getContentPane().add(txthost);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 160, 622, 271);
		frmSharedFolder.getContentPane().add(scrollPane);
		
		jTree = new JTree();
		scrollPane.setViewportView(jTree);
		DefaultTreeModel dmtn=null;
		jTree.setModel(dmtn);
		
		
		JLabel lblNewLabel_4 = new JLabel("Path");
		lblNewLabel_4.setBounds(357, 101, 56, 16);
		frmSharedFolder.getContentPane().add(lblNewLabel_4);
		
		txtPath = new JTextField();
		txtPath.setColumns(10);
		txtPath.setBounds(415, 98, 217, 22);
		frmSharedFolder.getContentPane().add(txtPath);
		
		JButton btnNewButton = new JButton("Connect");
		btnNewButton.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent arg0) {
				
				String username = txtusername.getText();
				String password = txtpassword.getText();
				String host 	= txthost.getText();
				String path		= txtPath.getText();
				String networkfolder = "smb://"+host+"/"+path+"/";
				String user = username + ":" + password;
				
				try{
	                
	                NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication(null,username,password);
	                SmbFile sFile = new SmbFile(networkfolder, auth);
	                if(sFile.exists()) {
	                	DefaultTreeModel dmtn;
	                	dmtn = new DefaultTreeModel(helper.showFiles(user, networkfolder, path));
	                	jTree.setModel(dmtn);
	                }else {
	                	JOptionPane.showMessageDialog(frmSharedFolder, "Failed to Connect");
	                }
	                
	            } catch (Exception e) {
	            	JOptionPane.showMessageDialog(frmSharedFolder, "Failed to Connect");
	            	e.printStackTrace();
	            }
			
			
			}
		});
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String username = txtusername.getText();
				String password = txtpassword.getText();
				String host 	= txthost.getText();
				String path		= txtPath.getText();
				String networkfolder = "smb://"+host+"/"+path+"/";
				String user = username + ":" + password;
				
				try{
	                
	                NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication(null,username,password);
	                SmbFile sFile = new SmbFile(networkfolder, auth);
	                if(sFile.exists()) {
	                	DefaultTreeModel dmtn;
	                	dmtn = new DefaultTreeModel(helper.showFiles(user, networkfolder, path));
	                	jTree.setModel(dmtn);
	                }else {
	                	JOptionPane.showMessageDialog(frmSharedFolder, "Failed to Connect");
	                }
	                
	            } catch (Exception e) {
	            	JOptionPane.showMessageDialog(frmSharedFolder, "Failed to Connect");
	            	e.printStackTrace();
	            }
				
			}
		});
		btnNewButton.setBounds(10, 129, 97, 25);
		frmSharedFolder.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Extract Report");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String username = txtusername.getText();
				String password = txtpassword.getText();
				String host 	= txthost.getText();
				String path		= txtPath.getText();
				String networkfolder = "smb://"+host+"/"+path+"/";
				String user = username + ":" + password;
				Data data[] = helper.getExcelData(user, networkfolder);
				exportToExcel(data);
			}
		});
		btnNewButton_1.setBounds(119, 129, 132, 25);
		frmSharedFolder.getContentPane().add(btnNewButton_1);
	}
	
	

public static void exportToExcel(Data[] filedata) {
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet spreadsheet = workbook.createSheet( " Folder Info ");
		Row row;
		row = spreadsheet.createRow(0);
		row.createCell(0).setCellValue("Name");
		row.createCell(1).setCellValue("Number of files");
		row.createCell(2).setCellValue("Creation time");
		row.createCell(3).setCellValue("Last Modified Time");
		row.createCell(4).setCellValue("isDirectory");
		row.createCell(5).setCellValue("size");
		row.createCell(6).setCellValue("path");
		
		
		try {
			CellStyle style = workbook.createCellStyle();
			style.setFillForegroundColor(IndexedColors.RED.getIndex());
			int rownumber = 2;
			
			for(Data files : filedata) {
				row = spreadsheet.createRow(rownumber++);
				if(files.numberOfFile >= 3) {
					
					Cell cell;
					cell = row.createCell(0);
					cell.setCellValue(files.name);
				    cell.setCellStyle(style);
					
					cell = row.createCell(1);
					cell.setCellValue(files.numberOfFile+"");
				    cell.setCellStyle(style);
					
				    
					cell = row.createCell(2);
					cell.setCellValue(files.creationTime);
				    cell.setCellStyle(style);
					
					cell = row.createCell(3);
					cell.setCellValue(files.lastmodified);
				    cell.setCellStyle(style);
					
					cell = row.createCell(4);
					cell.setCellValue(files.isDirectory+"");
				    cell.setCellStyle(style);
					
					cell = row.createCell(5);
					cell.setCellValue(files.size+"");
				    cell.setCellStyle(style);
					
					cell = row.createCell(6);
					cell.setCellValue(files.path);
				    cell.setCellStyle(style);
					
				}
				else {
					row.createCell(0).setCellValue(files.name);
					row.createCell(1).setCellValue(files.numberOfFile+"");
					row.createCell(2).setCellValue(files.creationTime);
					row.createCell(3).setCellValue(files.lastmodified);
					row.createCell(4).setCellValue(files.isDirectory+"");
					row.createCell(5).setCellValue(files.size+"");
					row.createCell(6).setCellValue(files.path);
				}
				
			}
			
			Random random  = new Random(1000);
			File f= new File("D://excelfile");
			f.mkdir();
			String filename = "D://excelfile/ExportedExcelFile"+random.nextInt()+".xls";
			f= new File(filename);
			f.createNewFile();
			FileOutputStream out = new FileOutputStream(f);
			workbook.write(out);
		    out.close();  
		    
		    int check = JOptionPane.showConfirmDialog(frmSharedFolder, 
                    "File Exported at : "+f.getAbsolutePath() ,
					  "Open File", JOptionPane.YES_NO_OPTION);
			if(check!=1) {
			try  
			{     
				if(!Desktop.isDesktopSupported())  
				{  
					return;  
				}  
				Desktop desktop = Desktop.getDesktop();  
				if(f.exists())           
					desktop.open(f);               
				}  
			catch(Exception e)  
			{ e.printStackTrace();}
			}
		    
		    
		} catch (Exception e) {
			System.out.println(e);
		} 
		
	}

	
}


